package com.example.mbassjsp.task5;

public class activitySwitch {
    public static NetworkConnectionAndReceiver networkConnectionAndReceiver;
}
